export var localurl = "https://dev.transforme.co.id/";
export var serverurl = "https://dev.transforme.co.id";
export var serverdevelurl = "https://dev.transforme.co.id";
export var develbase = "/epos-v2-content";
export var webserviceurl = "/epos-api";
